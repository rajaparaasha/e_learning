$(document).ready(function(){
		

	$("#click_quiz_btn").click(function(){
		$(this).attr("disabled","disabled");

		$("#view_note").html("* Don't Refresh Page...");
	})

});